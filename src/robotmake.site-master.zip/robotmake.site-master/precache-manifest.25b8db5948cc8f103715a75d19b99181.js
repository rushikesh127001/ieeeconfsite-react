self.__precacheManifest = [
  {
    "revision": "12a3db8ba7f5423327bb12aed3c41977",
    "url": "/static/media/SEGA.12a3db8b.woff"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "2955884a464e7712c5eb",
    "url": "/static/js/main.6b2c059e.chunk.js"
  },
  {
    "revision": "4716c8c675b35569eb5f",
    "url": "/static/js/2.1a543e43.chunk.js"
  },
  {
    "revision": "2955884a464e7712c5eb",
    "url": "/static/css/main.be6be324.chunk.css"
  },
  {
    "revision": "4716c8c675b35569eb5f",
    "url": "/static/css/2.d7070db3.chunk.css"
  },
  {
    "revision": "bab87fa15a56e9e012b6e3e932e69457",
    "url": "/index.html"
  }
];